/** Thrown by `jsonSnapshot` for a value JSON would change or lose. */
export declare class NotJsonError extends Error {
}
/**
 * A deep copy of `value` made only of what JSON holds: plain objects, arrays, strings,
 * finite numbers, booleans and null. Throws `NotJsonError` for anything JSON would change
 * or lose (a function, `NaN`, a `Map`, a circular reference…) rather than send something
 * other than what the app tracked. An object member that is `undefined` is left out, and
 * an object with `toJSON()` (a `Date`) is copied as what that answers, as `JSON.stringify` does.
 */
export declare function jsonSnapshot(value: unknown): unknown;
/** Whether `value` is a promise or another thenable. */
export declare function isThenable(value: unknown): value is PromiseLike<unknown>;
/** A plain object: not null, an array, or something like a Date. False when a getter it runs throws. */
export declare function isPlainObject(value: unknown): value is Record<string, unknown>;
