/** Every error the SDK throws, so an app can catch them all with one `instanceof`. */
export declare class KiroraError extends Error {
    readonly cause?: unknown | undefined;
    constructor(message: string, cause?: unknown | undefined);
}
/** `fetchUserToken` failed, didn't answer within 30 seconds, or there is no way to get a token. */
export declare class UserTokenError extends KiroraError {
    constructor(message?: string, cause?: unknown);
}
/** Kirora refused a call: its HTTP `status`, error `code` and the gap it asked for. */
export declare class KiroraApiError extends KiroraError {
    readonly status: number;
    readonly code?: string | undefined;
    /** From the `Retry-After` header, if any. */
    readonly retryAfterMs?: number | undefined;
    constructor(status: number, code?: string | undefined, message?: string, 
    /** From the `Retry-After` header, if any. */
    retryAfterMs?: number | undefined);
    /** True for 408, 425, 429 and 5xx: the same call may succeed later. */
    get retryable(): boolean;
}
