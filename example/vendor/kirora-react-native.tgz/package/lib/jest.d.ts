/**
 * A stand-in for `@kirora/react-native` in an app's Jest tests, where there is no native code:
 *
 * ```js
 * jest.mock('@kirora/react-native', () => require('@kirora/react-native/jest'));
 * ```
 *
 * Every method is a `jest.fn()` that answers what a working, signed-out SDK would, so tests can
 * assert on calls (`expect(kirora.track).toHaveBeenCalledWith('Order Completed', …)`).
 */
import { type KiroraState } from './backend';
import type { KiroraOptions } from './types';
export { KiroraApiError, KiroraError, UserTokenError } from './errors';
export { SDK_VERSION } from './version';
export declare class Kirora {
    readonly options: KiroraOptions;
    static active: Kirora | null;
    readonly isAvailable = true;
    constructor(options: KiroraOptions);
    identify: (_token?: string) => Promise<undefined>;
    logout: () => Promise<undefined>;
    track: (_name: string, _properties?: Record<string, unknown>) => undefined;
    trackScreenView: (_name: string) => undefined;
    setTrackingConsent: (_granted: boolean) => undefined;
    setPushConsent: (_granted: boolean) => Promise<undefined>;
    requestPushPermission: () => Promise<"granted">;
    getPushStatus: () => Promise<"disabled">;
    setPushEnabled: (_enabled: boolean) => Promise<undefined>;
    flush: () => Promise<undefined>;
    destroy: () => undefined;
    getState: () => Promise<KiroraState>;
    onNotificationClicked: (_listener: (data: Record<string, string>) => void) => () => undefined;
    onNotificationReceived: (_listener: (data: Record<string, string>) => void) => () => undefined;
    onNewPushToken: (_token: string) => undefined;
    onPushRegistered: (_installationId: string) => undefined;
}
