import { type KiroraBackend, type KiroraState } from './backend';
import type { PushPermission, PushStatus } from './types';
/**
 * Why there is no native SDK: not linked (Expo Go, a build made before installing), the web,
 * or another platform it doesn't run on (react-native-windows, react-native-macos).
 */
export type Unavailable = 'unlinked' | 'web' | 'unsupported-platform';
/**
 * Where there is no native SDK: every call is a safe no-op, so the app keeps working, and one
 * error says why nothing is sent.
 */
export declare class UnavailableBackend implements KiroraBackend {
    constructor(logErrors: boolean, why: Unavailable);
    identify(): Promise<void>;
    logout(): Promise<void>;
    track(): void;
    trackScreenView(): void;
    setTrackingConsent(): void;
    setPushConsent(): Promise<void>;
    requestPushPermission(): Promise<PushPermission>;
    getPushStatus(): Promise<PushStatus>;
    setPushEnabled(): Promise<void>;
    flush(): Promise<void>;
    destroy(): void;
    getState(): Promise<KiroraState>;
    onNewPushToken(): void;
    onPushRegistered(): void;
    onNotificationClicked(): () => void;
    onNotificationReceived(): () => void;
}
