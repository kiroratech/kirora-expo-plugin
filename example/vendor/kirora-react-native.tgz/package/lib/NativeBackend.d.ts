import { type KiroraBackend, type KiroraState } from './backend';
import { KiroraError } from './errors';
import type { KiroraOptions, NotificationData, PushPermission, PushStatus } from './types';
/** The methods of the `KiroraSdk` native module: `android/src/main/java/io/kirora/reactnative`, `ios/`. */
export interface NativeKiroraModule {
    /** Answers whether tracking is allowed now: a remembered choice, or the default. */
    configure(options: NativeOptions): Promise<{
        trackingConsent?: boolean;
    } | null | void>;
    identify(token: string | null): Promise<void>;
    logout(): Promise<void>;
    track(name: string, propertiesJson: string): void;
    trackScreenView(name: string): void;
    setTrackingConsent(granted: boolean): void;
    /** Resolves once Kirora recorded it; rejects like `identify`. */
    setPushConsent(granted: boolean): Promise<void>;
    requestPushPermission(): Promise<PushPermission>;
    flush(): Promise<void>;
    /** Null when there is no client, or its state can't be read. */
    getState(): Promise<KiroraState | null>;
    onNewPushToken(token: string): void;
    onPushRegistered(installationId: string): void;
    getPushStatus(): Promise<PushStatus>;
    setPushEnabled(enabled: boolean): Promise<void>;
    destroy(): void;
    /** Answers a `KiroraTokenRequest` event: a token, or an error message when `fetchUserToken` failed. */
    resolveToken(requestId: string, token: string | null, error: string | null): void;
    /**
     * Answers a `KiroraForegroundNotification` event (show the push, or hold it back) or a
     * `KiroraDeepLink` event (whether the app opened the link itself).
     */
    resolveAnswer(requestId: string, answer: boolean): void;
    /** Starts (or stops) `KiroraNotificationClicked` / `KiroraNotificationReceived` events; taps that arrived earlier follow at once. */
    setNotificationEvents(clicked: boolean, received: boolean): void;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
export interface NativeOptions {
    clientKey: string;
    apiUrl: string;
    push: boolean;
    pushAppId: string | null;
    requireTrackingConsent: boolean;
    trackSessions: boolean;
    trackAppLifecycle: boolean;
    logLevel: string;
    hasTokenProvider: boolean;
    hasAuthenticationFailedHandler: boolean;
    smallIcon: string | null;
    accentColor: string | null;
    defaultChannelId: string | null;
    defaultChannelName: string | null;
    hasForegroundHandler: boolean;
    hasDeepLinkHandler: boolean;
    /** This package's version, sent as `Kirora-SDK: kirora-react-native/<version>`. */
    sdkVersion: string;
}
export interface NativeEventEmitterLike {
    addListener(eventName: string, listener: (event: any) => void): {
        remove(): void;
    };
}
/**
 * Hands every call to the native Kirora Android or iOS SDK. `fetchUserToken`, `handleDeepLink`
 * and `onForegroundNotification` stay in JavaScript: the native SDK asks with an event, and the
 * answer goes back with `resolveToken` or `resolveAnswer`. `beforeSend`
 * runs here, on the events the app tracks, before they cross. Notification opens are reported
 * by the native SDK on its own.
 *
 * Every call goes to the native module at once, not after `configure` settles (unless an event
 * waits, see `NativeQueue`): the module runs calls in order, after the `configure` this client
 * sent, so a call reaches the client that was current when it was made, even if a newer one
 * replaces it right after (a withdrawn consent).
 */
export declare class NativeBackend implements KiroraBackend {
    private readonly native;
    private readonly emitter;
    private readonly configured;
    private readonly queue;
    private readonly subscriptions;
    private readonly clickListeners;
    private readonly receivedListeners;
    private destroyed;
    private inBeforeSend;
    /** Why the native setup failed, for `identify` to reject with. */
    private setupError?;
    private readonly beforeSend;
    /**
     * Whether tracking is allowed: the app's latest choice, else the native SDK's answer at setup
     * (undefined until it answers, or when setup failed). `beforeSend` never sees an event
     * tracking doesn't allow.
     */
    private freshConsent?;
    private storedConsent?;
    private readonly logErrors;
    constructor(options: KiroraOptions & {
        clientKey: string;
    }, native: NativeKiroraModule, emitter: NativeEventEmitterLike);
    /**
     * Answers the native SDK's `event` with `handler`'s result: `fallback` when it throws or
     * rejects. Not asked once the native SDK stopped waiting: it has acted by then (opened the
     * link, shown the push), and the app's callback would act a second time.
     */
    private answer;
    /**
     * Sends a call through the queue (at once, see the class), then answers what the native SDK
     * did, mapped to the SDK's errors; a failed setup rejects with why. `whenDestroyed` once this
     * client is destroyed, whatever it was given. `invalid` rejects without sending: an argument
     * of the wrong type, which the bridge refuses (a crash on Android's old architecture).
     */
    private call;
    /**
     * Sends a call that answers nothing (`track`, an answer to the native SDK) through the queue, after
     * `ready` if given. What the native module throws is logged: it never reaches the app, as an
     * exception or an unhandled rejection.
     */
    private fire;
    /** `call`, logging and answering `fallback` instead of rejecting. */
    private quietly;
    /** Rejects with what the native SDK threw: `UserTokenError`, `KiroraApiError` or `KiroraError`. */
    identify(token?: string): Promise<void>;
    /** Never rejects. */
    logout(): Promise<void>;
    track(name: string, properties?: Record<string, unknown>): void;
    /** What the native module answers, so a promise it rejects is logged by `fire`. */
    private release;
    private send;
    trackScreenView(name: string): void;
    /** Never queued: a refusal takes effect at once, and blocks the events still waiting. */
    setTrackingConsent(granted: boolean): void;
    /** Resolves once Kirora recorded the choice; rejects, as `identify` does, when it didn't. */
    setPushConsent(granted: boolean): Promise<void>;
    /** Never rejects: `unsupported` when the native SDK can't answer (a failed setup, say). */
    requestPushPermission(): Promise<PushPermission>;
    /** Never rejects: `unsupported` when the native SDK can't answer (a failed setup, say). */
    getPushStatus(): Promise<PushStatus>;
    /** Never rejects. */
    setPushEnabled(enabled: boolean): Promise<void>;
    /** Never rejects. */
    flush(): Promise<void>;
    /** Never rejects: the empty state when it can't be read. */
    getState(): Promise<KiroraState>;
    /**
     * Stops this client's listeners; the native SDK keeps what waits. `stopNative` when it is the
     * current client: a replaced one leaves the module to the client that set it up again. Queued
     * like any call, so events still waiting reach the native SDK first.
     */
    destroy(stopNative: boolean): void;
    /**
     * The event's properties copied as JSON now, as `track` was called. Undefined when it is
     * dropped. Only the failure's kind is logged, never the event. Getters of the app's objects
     * run only inside guards: one that throws drops the event.
     */
    private snapshot;
    /** The event as `beforeSend` leaves it; undefined when it drops it or answers wrongly. */
    private applyBeforeSend;
    /** Hands a notification to the app's listeners; one that throws doesn't stop the others. */
    private deliver;
    /**
     * Runs the app's callback or a native call (`failed`); an error it throws is logged, never
     * thrown on. False when it threw.
     */
    private safely;
    private error;
    onNewPushToken(token: string): void;
    onPushRegistered(installationId: string): void;
    onNotificationClicked(listener: (data: NotificationData) => void): () => void;
    onNotificationReceived(listener: (data: NotificationData) => void): () => void;
    private listen;
    /** Never after destroy: the native module may serve a newer client by then. */
    private syncNotificationEvents;
}
/**
 * A native module's rejection as one of the SDK's errors. The modules reject with a code
 * (`USER_TOKEN_ERROR`, `KIRORA_API_ERROR` with `status`, `code` and `retryAfterMs` in `userInfo`,
 * anything else for a setup or network problem) and the native SDK's message.
 */
export declare function errorFromNative(e: unknown): KiroraError;
